% PheomoneType Enum Class
% author - Harry Howarth
% date - 14/05/18
classdef PheromoneType
   enumeration
      Exploratory, Food
   end
end