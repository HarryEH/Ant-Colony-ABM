% AntType Enumeration
% author - Harry Howarth
% date - 14/05/18
classdef AntType
    enumeration
      Scout, Worker
    end
end

