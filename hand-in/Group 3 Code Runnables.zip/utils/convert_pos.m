function [ x1, y1 ] = convert_pos( x, y )
%CONVERT_POS_DES Summary of this function goes here
%   Detailed explanation goes here
    x1 = (int16(x));
    y1 = (int16(y));
end

